from ast import If
#from crypt import methods
import email
from pickle import GET
from urllib.request import Request
from flask import Flask, jsonify,session
from os.path import dirname, join
from flask import request
from flask.templating import render_template
#from flask_mysqldb import MySQL
import secrets
import numpy as np
import pandas as pd
import os

# Print the current working directory
print("Current working directory:", os.getcwd())

app = Flask(__name__)

secret = secrets.token_urlsafe(32)

app.secret_key = secret

app.config['MYSQL_HOST'] = "localhost"
app.config['MYSQL_USER'] = "root"
app.config['MYSQL_PASSWORD'] = "rohit45"
app.config['MYSQL_DB'] = "mysql"

#mysql = MySQL(app)
@app.route("/feedback",methods=['GET','POST'])
def feedback():
    if request.method == 'POST':
        rating = request.form['experience']
        comm = request.form['comments']
        username = request.form['name']
        email = request.form['email']
        
        #cur = mysql.connection.cursor()
        #cur.execute("INSERT INTO persons (Rating,Comments,Name, email) VALUES (%s,%s,%s,%s)",(rating,comm,username,email))
        #mysql.connection.commit()
        #cur.close()
        #cur1 = mysql.connection.cursor()
       # cur1.execute("Select Rating,Comments,Name from persons")
        #data = cur1.fetchall()
        #cur1.close()
        #return render_template('result.html', res = data)
        
    return render_template('feedback.html')

@app.route("/")
def index():
    return render_template('preload.html')


@app.route("/about")
def us():
    return render_template('about1.html')


@app.route("/home")
def home():
    return render_template('preload.html')


@app.route("/main")
def main():
    return render_template('Main.html')

@app.route("/med")
def med():
    d=session.get("daff")
    return render_template('homeremmedy.html',d=d)

@app.route("/predict")
def predict():
    d=session.get("daff")
    return render_template('medicine.html',med=d[-1])

@app.route("/covidtracker")
def covid():
    return render_template('traker.html')

@app.route("/feedback")
def feedbackview():
    return render_template('result.html')
    
@app.route("/find",methods = ['POST'])
def hello():
    l1f = pd.read_csv("data_sympt.csv")
    l1 = l1f['Symptoms']
    s1 = request.form['s1']
    s2 = request.form['s2']
    s3 = request.form['s3']
    s4 = request.form['s4']
    s5 = request.form['s5']

    symptoms = [s1,s2,s3,s4,s5]
    

    disease=['Fungal infection','Allergy','GERD','Chronic cholestasis','Drug Reaction',
    'Peptic ulcer diseae','AIDS','Diabetes','Gastroenteritis','Bronchial Asthma','Hypertension',
    ' Migraine','Cervical spondylosis',
    'Paralysis (brain hemorrhage)','Jaundice','Malaria','Chicken pox','Dengue','Typhoid','hepatitis A',
    'Hepatitis B','Hepatitis C','Hepatitis D','Hepatitis E','Alcoholic hepatitis','Tuberculosis',
    'Common Cold','Pneumonia','Dimorphic hemmorhoids(piles)',
    'Heartattack','Varicoseveins','Hypothyroidism','Hyperthyroidism','Hypoglycemia','Osteoarthristis',
    'Arthritis','(vertigo) Paroymsal  Positional Vertigo','Acne','Urinary tract infection','Psoriasis',
    'Impetigo']
    l2=[]
    for i in range(0,len(l1)):
        l2.append(0)

    df=pd.read_csv("Prod_1.csv")
    medf = pd.read_csv("remedy.csv").fillna('')
    

    def DTree(sym):
        from sklearn import tree
        import joblib
        

        clf3 = joblib.load('modelDTree.pkl')

        psymptoms = sym
        res = ""

        for k in range(0,len(l1)):
            for z in psymptoms:
                if(z==l1[k]):
                    l2[k]=1

        inputtest = [l2]
        predict = clf3.predict(inputtest)
        predicted=predict[0]

        h='no'
        for a in range(0,len(disease)):
            if(predicted == a):
                h='yes'
                break


        if (h=='yes'):
            res = disease[a]
        else:
            res = "Not found"

        return res

    def randomforest(sym):
        from sklearn.ensemble import RandomForestClassifier
        import joblib
        # clf4 = RandomForestClassifier()
        # clf4 = clf4.fit(X,np.ravel(y))

        # # calculating accuracy 
        # from sklearn.metrics import accuracy_score
        # y_pred=clf4.predict(X_test)
        # print(accuracy_score(y_test, y_pred))
        # print(accuracy_score(y_test, y_pred,normalize=False))

        clf4 = joblib.load('modelRF.pkl')
        
        psymptoms = sym
        for k in range(0,len(l1)):
            for z in psymptoms:
                if(z==l1[k]):
                    l2[k]=1

        inputtest = [l2]
        predict = clf4.predict(inputtest)
        predicted=predict[0]

        h='no'
        for a in range(0,len(disease)):
            if(predicted == a):
                h='yes'
                break

        if (h=='yes'):
            res = disease[a]
        else:
            res = "Not found"


        return res




    def NaiveBayes(sym):
        from sklearn.naive_bayes import GaussianNB
        import joblib
        # gnb = GaussianNB()
        # gnb=gnb.fit(X,np.ravel(y))

        # from sklearn.metrics import accuracy_score
        # y_pred=gnb.predict(X_test)
        # print(accuracy_score(y_test, y_pred))
        # print(accuracy_score(y_test, y_pred,normalize=False))

        gnb = joblib.load('modelNB.pkl')

        psymptoms = sym
        for k in range(0,len(l1)):
            for z in psymptoms:
                if(z==l1[k]):
                    l2[k]=1

        inputtest = [l2]
        predict = gnb.predict(inputtest)
        predicted=predict[0]

        h='no'
        for a in range(0,len(disease)):
            if(predicted == a):
                h='yes'
                break

        if (h=='yes'):
            res = disease[a]
        else:
            res = "Not found"


        return res

    # sym = symptoms.split(",")
    dc = DTree(symptoms)
    a = ','.join(map(str, medf[dc]))
    mdc = dc + ',' + a

    nb=NaiveBayes(symptoms)
    b = ','.join(map(str, medf[nb]))
    mnb = nb + ',' + b

    rf=randomforest(symptoms)
    c = ','.join(map(str, medf[rf]))
    mrf = rf + ',' + c
    # result = {
    #     'res1': mdc,
    #     'res2': mnb,
    #     'res3': mrf
    # }
    d1 = mdc.split(',')
    d2 = mnb.split(',')
    d3 = mrf.split(',')

    if(d1[0] == d2[0]):
        d = d1
    elif(d2[0] == d3[0]):
        d = d2
    else:
        d = d1


    #return jsonify(result)
    # return jsonify(res)
    session["daff"] = d
    return render_template("prediction.html",d1 = d1, d2 = d2, d3 = d3, d = d, med = d[-1])
   




if __name__ == "__main__":
    app.run(debug=True)
